
let buildings = [];
let forest = [];
let water = [];
let roads = [];
let treffpunkte = [];
let spielplätze = [];
let primarschulen = [];
let sekundarschulen = [];
let freiraum = [];
let bushaltestellen = [];
let migros = [];
let deutschkurse = [];
let spitäler = [];
let zentrum = [];
let migration = [];
let kindergärten = [];

let img = [];

let zoom = 1000000;


let currentScore = 0;
let currentPosition = {
  lat: 0,
  lon: 0  
}




let projection = d3.geoMercator()
 // .center([8.307535579705162, 47.05203406352773])
  //.center([8.289093914277919, 47.057026689857906])
  //.center([8.269513814567075, 47.059496405629346])
  .center([8.275093549013384, 47.05082294647473])
  // .translate([1250, 550])
  .translate([400, 300])
  .scale(zoom);

let quadtreeMigros = d3.quadtree();
let quadtreePrim = d3.quadtree();
let quadtreeSek = d3.quadtree();
let quadtreeSpiel = d3.quadtree();
let quadtreeKiga = d3.quadtree();
let quadtreeFrei = d3.quadtree();
let quadtreeTreff = d3.quadtree();
let quadtreeBus = d3.quadtree();
let quadtreeDeutsch = d3.quadtree();





function preload() {
  buildings = loadJSON("buildings.geojson");
  forest = loadJSON("forest.geojson");
  water = loadJSON("water.geojson");
  roads = loadJSON("roads.geojson");
  treffpunkte = loadJSON("Interkulturelle.json");
  spielplätze = loadJSON("Spiel.json");
  primarschulen = loadJSON("prim.json");
  sekundarschulen = loadJSON("sek.json");
  freiraum = loadJSON("freiraumkorrekt.json");
  bushaltestellen = loadJSON("bushoffentlich.geojson");
  migros = loadJSON("migros_scraped.geojson");
  kindergärten = loadJSON("kiga.json");


  img = loadImage('FürCodeMockup.jpg');

}


function setup() {
  createCanvas(1900, 900);
  //createCanvas(800, 600, SVG);
  noLoop();

  


  d3.csv("Deutschkurse.csv", d3.autoType).then(function (csv) {
    deutschkurse = csv

    quadtreeDeutsch = d3.quadtree()
    .x(function (d) {
      return d.lon
    })
    .y(function (d) {
      return d.lat
    })
    .addAll(deutschkurse)

    redraw();
  })

  
   d3.csv("Spitäler.csv", d3.autoType).then(function (csv) {
   spitäler = csv

   quadtreeSpital = d3.quadtree()
   .x(function (d) {
     return d.lon
   })
   .y(function (d) {
     return d.lat
   })
   .addAll(spitäler)

   redraw();
  })


  d3.csv("Stadtzentrum.csv", d3.autoType).then(function (csv) {
    zentrum = csv
    redraw();
  })


  d3.csv("Migration.csv", d3.autoType).then(function (csv) {
    migration = csv
    redraw();
  })



  quadtreeMigros = d3.quadtree()
    .x(function (d) {
     return d.properties["location/geo/lon"]
    })
    .y(function (d) {
      return d.properties["location/geo/lat"]
    })
    .addAll(migros.features)




  quadtreePrim = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(primarschulen.features)



    quadtreeSek = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(sekundarschulen.features)


    quadtreeSpiel = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(spielplätze.features)

    
    quadtreeKiga = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(kindergärten.features)

        
    quadtreeFrei = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(freiraum.features)



    quadtreeTreff = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(treffpunkte.features)
    


    quadtreeBus = d3.quadtree()
    .x(function (d) {
      return d.geometry.coordinates[0]
    })
    .y(function (d) {
      return d.geometry.coordinates[1]
    })
    .addAll(bushaltestellen.features)



    


    // let upperLeft = projection.invert([0, 0]);
    // let lowerRight = projection.invert([800, 600]);
    // // find best location
    // for(let i=0; i<10; i++){
    //   for(let j=0; j<10; j++){

    //   }
    // }

}





function draw() {
  background(255);

  //console.log("draw");

  drawBuildings();
  drawForest();
  drawWater();
  drawRoads();
  //drawTreffpunkte();
  //drawSpielplätze();
  //drawPrimarschulen();
  //drawSekundarschulen();
  //drawFreiraum();
  //drawBushaltestellen();
  //drawMigros();
  //drawDeutschkurse();
  //drawSpitäler();
  //drawZentrum();
  //drawMigration();
  //drawText();
  //drawKindergärten();

  //drawInterface();

  
  image(img, 1000,1900,900,600);

  let scorePos = projection([currentPosition.lon, currentPosition.lat])
  noStroke();
  fill(239, 70, 49,150);
  ellipse (mouseX,mouseY,80,80)
  fill(255,255,255);
  ellipse (mouseX,mouseY,5,5)

  stroke (255);
  fill (255,255,255,200);
  rect(mouseX + 10, mouseY -5, 100, 20, 20)

  textSize(14)
  noStroke();
  fill(0);
  text("Score: " + round(currentScore), scorePos[0] + 20, scorePos[1] + 10);
  

}







function drawZentrum() {

  for (let i = 0; i < zentrum.length; i++) {
    let pos = projection([zentrum[i].lon, zentrum[i].lat])
    fill(0,0,255);
    ellipse(pos[0], pos[1], 50, 50);
  }
}



function drawMigration() {

  for (let i = 0; i < migration.length; i++) {
    let pos = projection([migration[i].lon, migration[i].lat])
    fill(0,0,255);
    ellipse(pos[0], pos[1], 100, 100);
  }
}




function drawSpitäler() {

  for (let i = 0; i < spitäler.length; i++) {
    let pos = projection([spitäler[i].lon, spitäler[i].lat])
    fill(0,0,255);
    ellipse(pos[0], pos[1], 30, 30);
  }
}



function drawDeutschkurse() {

  for (let i = 0; i < deutschkurse.length; i++) {
    let pos = projection([deutschkurse[i].lon, deutschkurse[i].lat])
    fill(0,0,255);
    ellipse(pos[0], pos[1], 15, 15);
  }
}



function drawInterface() {

  fill(239, 70, 49)
  noStroke();
rect(0,0,500,900)

}


function drawText() {

  textSize(50)
  fill(215, 207, 1)
  text("Gebäude", 20, 50)
  fill(127, 190, 156)
  text("Bushaltestellen", 20, 100)
  fill(0, 0, 0)
  text("Interkulturelle Treffpunkte", 20, 150)
  fill(0, 22, 110)
  text("Spielplätze", 20, 200)
  fill(215, 214, 146)
  text("Grundschulen", 20, 250)
  fill(94, 92, 8)
  text("Migros", 20, 350)
  fill(69, 105, 6)
  text("Deutschkurse", 20, 400)
  fill(112, 77, 168)
  text("Spitäler", 20, 450)
  fill(238, 255, 125, 100);
  text("Stadtzentrum", 20, 500)
  fill(47, 19, 56);
  text("Von Migration geprägter Stadtteil", 20, 550)
  stroke(75)
  noFill()
  text("Freiraumflächen", 20, 300)

}


function keyTyped() {

  console.log("keyTyped");
  if (key == "a") {
    zoom = zoom - 100000;
    projection.scale(zoom);
  }
  redraw();
  if (key == "s") {
    zoom = zoom + 100000;
    projection.scale(zoom);
    redraw();
  }
}






function drawBuildings() {

  for (let i = 0; i < buildings.features.length; i++) {
    let feature = buildings.features[i];
    let coordinates = feature.geometry.coordinates[0]
    fill(239, 70, 49)
    noStroke()
    beginShape();
    for (let j = 0; j < coordinates.length; j++) {
      let pos = projection(coordinates[j])
      vertex(pos[0], pos[1]);
    }
    endShape();
  }
}






function drawBushaltestellen() {

  for (let i = 0; i < bushaltestellen.features.length; i++) {
    let feature = bushaltestellen.features[i];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()

    //console.log(feature.geometry.type);

    if (feature.geometry.type == "Point") {
      let pos = projection(coordinates)
      ellipse(pos[0], pos[1], 30, 30);
    }
  }
}









function drawMigros() {

  for (let i = 0; i < migros.features.length; i++) {
    let feature = migros.features[i];
    let lat = feature.properties["location/geo/lat"]
    let lon = feature.properties["location/geo/lon"]
    //console.log(lon)
    fill(0,0,255)
    noStroke()
    let pos = projection([lon, lat])
    ellipse(pos[0], pos[1], 15, 15);
    //console.log(pos)

  }
}







function drawFreiraum() {

  for (let i = 0; i < freiraum.features.length; i++) {
    let feature = freiraum.features[i];
    let coordinates = feature.geometry.coordinates[0]
    stroke(0,0,255)
    noFill()
    beginShape();
    for (let j = 0; j < coordinates.length; j++) {
      let pos = projection(coordinates[j])
      vertex(pos[0], pos[1]);
    }
    endShape();
  }
}







function drawTreffpunkte() {

  for (let j = 0; j < treffpunkte.features.length; j++) {
    let feature = treffpunkte.features[j];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()
    let pos = projection(coordinates)
    ellipse(pos[0], pos[1], 30, 30);
  }
}




function drawSpielplätze() {

  for (let j = 0; j < spielplätze.features.length; j++) {
    let feature = spielplätze.features[j];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()
    let pos = projection(coordinates)
    ellipse(pos[0], pos[1], 15, 15);
  }
}



function drawPrimarschulen() {

  for (let j = 0; j < primarschulen.features.length; j++) {
    let feature = primarschulen.features[j];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()
    let pos = projection(coordinates)
    ellipse(pos[0], pos[1], 15, 15);
  }
}


function drawKindergärten() {

  for (let j = 0; j < kindergärten.features.length; j++) {
    let feature = kindergärten.features[j];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()
    let pos = projection(coordinates)
    ellipse(pos[0], pos[1], 45, 45);
  }
}



function drawSekundarschulen() {

  for (let j = 0; j < sekundarschulen.features.length; j++) {
    let feature = sekundarschulen.features[j];
    let coordinates = feature.geometry.coordinates
    fill(0,0,255)
    noStroke()
    let pos = projection(coordinates)
    ellipse(pos[0], pos[1], 15, 15);
  }
}


function drawWater() {
  for (let w = 0; w < water.features.length; w++) {
    let feature = water.features[w];
    let coordinates = feature.geometry.coordinates[0]
    fill(163, 168, 242)
    noStroke()
    beginShape();
    for (let a = 0; a < coordinates.length; a++) {
      let pos = projection(coordinates[a])
      vertex(pos[0], pos[1]);
    }
    endShape();
  }

}


function drawForest() {

  for (let i = 0; i < forest.features.length; i++) {
    let feature = forest.features[i];
    let coordinates = feature.geometry.coordinates[0]
    if (feature.properties["@id"] == "relation/1298342") {
      //fill(19, 50, 44)
      fill(19,58,51);
      //}else{
      //fill("#DDE31F")
    }
    noStroke()
    beginShape();
    for (let j = 0; j < coordinates.length; j++) {
      let pos = projection(coordinates[j])
      vertex(pos[0], pos[1]);
    }
    endShape();
  }
}



function drawRoads() {
  noFill()
  strokeWeight(1);
  stroke(215, 239, 218);
  for (let r = 0; r < roads.features.length; r++) {
    let feature = roads.features[r];
    let coordinates = feature.geometry.coordinates
    beginShape();
    for (let b = 0; b < coordinates.length; b++) {
      let pos = projection(coordinates[b])
      vertex(pos[0], pos[1]);
    }
    endShape();
  }
}


function mouseClicked(){
  
  // calculate the latitude and longitude of the mouse position using the inverse projection
  let mouseLatLon = projection.invert([mouseX, mouseY]);
  console.log('mouseclicked',mouseLatLon);

  currentPosition.lon = mouseLatLon[0];
  currentPosition.lat = mouseLatLon[1];

  // MIGROS
  // get the closest migros point to the mouse position using quadtreeMigros
  let closestMigros = quadtreeMigros.find(currentPosition.lon, currentPosition.lat);
  let distanceMigros = dist(currentPosition.lon, currentPosition.lat, closestMigros.properties["location/geo/lon"], closestMigros.properties["location/geo/lat"]);
  //console.log('closestMigros',closestMigros,distanceMigros);

  // PRIMARSCHULEN
  // get the closest primarschule point to the mouse position using quadtreePrim
  let closestPrim = quadtreePrim.find(currentPosition.lon, currentPosition.lat);
  let distancePrim = dist(currentPosition.lon, currentPosition.lat, closestPrim.geometry.coordinates[0], closestPrim.geometry.coordinates[1]);
  //console.log('closestPrim',closestPrim,distancePrim);

//Sekundarschulen
  let closestSek = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
  let distanceSek = dist(currentPosition.lon, currentPosition.lat, closestSek.geometry.coordinates[0], closestSek.geometry.coordinates[1]);
  //console.log('closestSek',closestSek,distanceSek);

  
//Spielplätze
let closestSpiel = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
let distanceSpiel = dist(currentPosition.lon, currentPosition.lat, closestSpiel.geometry.coordinates[0], closestSpiel.geometry.coordinates[1]);
//console.log('closestSpiel',closestSpiel,distanceSpiel);


//Kindergärten
let closestKiga = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
let distanceKiga = dist(currentPosition.lon, currentPosition.lat, closestKiga.geometry.coordinates[0], closestKiga.geometry.coordinates[1]);
//console.log('closestKiga',closestKiga,distanceKiga);


//Freiraum
let closestFrei = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
let distanceFrei = dist(currentPosition.lon, currentPosition.lat, closestFrei.geometry.coordinates[0], closestFrei.geometry.coordinates[1]);
//console.log('closestFrei',closestFrei,distanceFrei);



//Treffpunkte
let closestTreff = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
let distanceTreff = dist(currentPosition.lon, currentPosition.lat, closestTreff.geometry.coordinates[0], closestTreff.geometry.coordinates[1]);
//console.log('closestTreff',closestTreff,distanceTreff);



//Bushaltestellen
let closestBus = quadtreeSek.find(currentPosition.lon, currentPosition.lat);
let distanceBus = dist(currentPosition.lon, currentPosition.lat, closestBus.geometry.coordinates[0], closestBus.geometry.coordinates[1]);
//console.log('closestBus',closestBus,distanceBus);


//Deutschkurse
let closestDeutsch = quadtreeDeutsch.find(currentPosition.lon, currentPosition.lat);
let distanceDeutsch = dist(currentPosition.lon, currentPosition.lat, closestDeutsch.lon, closestDeutsch.lat);
//console.log('closestDeutsch',closestDeutsch,distanceDeutsch);

//Spitäler
let closestSpital = quadtreeSpital.find(currentPosition.lon, currentPosition.lat);
let distanceSpital = dist(currentPosition.lon, currentPosition.lat, closestSpital.lon, closestSpital.lat);
//console.log('closestSpital',closestSpital,distanceSpital);





  // add the distances together to get a score
  // like this, the lower the score the better
  // would have to be scaled in order to make a score which is the higher the better
  currentScore = 100 - 1000*(distanceMigros + distancePrim + distanceSek + distanceSpiel + distanceKiga + distanceBus + distanceTreff + distanceTreff + distanceDeutsch);


  console.log('currentScore',currentScore);


  redraw();
}








//     []  {}   #
